import Navbar from "./navbar";

function AddProduct(){

    return( 
<>
<body className="bgmarket">
   <div>
     <Navbar />
   </div>
   <div className="cont p-3">
   <h1 >hmmmmm</h1>
   </div>
</body>
</>
    );
}
export default AddProduct; 